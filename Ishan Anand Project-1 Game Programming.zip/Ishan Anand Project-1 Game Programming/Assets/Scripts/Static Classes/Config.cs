﻿using UnityEngine;
using System.Collections;
using Origin.World;

public static class Config {

    public static bool isGameAvailable;
    public static float Epsilon = 0.001f;
    public static int spawns;
    public static string stagePrefix = "Level 1";
}
